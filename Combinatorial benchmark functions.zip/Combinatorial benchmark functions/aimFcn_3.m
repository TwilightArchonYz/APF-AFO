function [y,result]=aimFcn_3(x,data)
    x=reshape(x,data.numV,data.numNode);
    flag=zeros(data.numNode,1);
    flag(1:data.numC)=1; %中心不需要配送
    path=cell(data.numV);
    for noV=1:data.numV
        path{noV}=[data.noC(noV)];
    end
    nowP_V=data.noC;           %每辆车的初始位置
    load_V=zeros(data.numV,1); %每辆车配送时的最大装载
    nowT_V=zeros(data.numV,1); %车辆当前时间
    sumD_V=zeros(data.numV,1); %车辆当前时间
    recording=[];
    while 1 
        p=find(flag==0);
        if isempty(p)
            break;
        end
        D=zeros(data.numV,length(p));
        pri=D;
        gapT=D;
        for noV=1:data.numV
            for j=1:length(p)
                nextP=p(j); 
                nowP=nowP_V(noV);
                nowT=nowT_V(noV);
                D(noV,j)=data.D(nowP,nextP);
                pri(noV,j)=x(noV,j);
                need=data.demand(nextP);
                windows=data.windows(nextP,:);
                AT=nowT+D(noV,j)/data.v;
                if AT>windows(2) || AT<windows(1)
                    gapT(noV,j)=min(abs(AT-windows));
                else
                    gapT(noV,j)=0;
                end
                if need+load_V(noV)>data.maxLoad
                    pri(noV,j)=inf;
                end
                if AT>data.H_windows(2) || AT<data.H_windows(1)
                    pri(noV,j)=inf;
                end
                if sumD_V(noV)+D(noV,j)>data.maxD
                    pri(noV,j)=inf;
                end
            end
        end
        temp1=myMapminmax(gapT);
        temp2=myMapminmax(pri);
        temp3=myMapminmax(D);
        temp=temp1+temp2+temp3;
        [noV,p2]=find(temp==min(min(temp)));
        noV=noV(1);
        p2=p2(1);
        nextP=p(p2);
        nowP=nowP_V(noV);
        nowT=nowT_V(noV);
        D=data.D(nowP,nextP);
        need=data.demand(nextP);
        windows=data.windows(nextP,:);
        AT=nowT+D/data.v;
        if AT>windows(2) || AT<windows(1)
            gapT=min(abs(AT-windows));
        else
            gapT=0;
        end
        ET=AT+data.ST;
        recording=[recording;noV,nowP,nextP,nowT,AT,ET,D,gapT];
        flag(nextP)=1;
        sumD_V(noV)=sumD_V(noV)+D;
        load_V(noV)=load_V(noV)+need;
        nowP_V(noV)=nextP;
        nowT_V(noV)=ET;
        path{noV}=[path{noV};nextP];
    end
    for noV=1:data.numV
        nextP=data.noC(noV);
        nowP=nowP_V(noV);
        nowT=nowT_V(noV);
        D=data.D(nowP,nextP);
        need=data.demand(nextP);
        windows=data.windows(nextP,:);
        AT=nowT+D/data.v;
        if AT>windows(2) || AT<windows(1)
            gapT=min(abs(AT-windows));
        else
            gapT=0;
        end
        ET=AT+data.ST;
        recording=[recording;noV,nowP,nextP,nowT,AT,ET,D,gapT];
        flag(nextP)=1;
        sumD_V(noV)=sumD_V(noV)+D;
        load_V(noV)=load_V(noV)+need;
        nowP_V(noV)=nextP;
        nowT_V(noV)=ET;
        path{noV}=[path{noV};nextP];
    end
    y=sum(recording(:,7))*data.C1+sum(recording(:,8))*data.C2;
    result.recording=recording;
    result.path=path;
end