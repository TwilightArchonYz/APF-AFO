function [bestX,bestY,recording]=func_PSO(dim,lb,ub,temp,data)
    %% PSO�㷨
    option.ub            = ub*ones(1,dim);  % Upper bound for all dimensions
    option.lb            = lb*ones(1,dim);  % Lower bound for all dimensions
    option.D             = dim;             % Dimensionality of the problem
    if dim<100
        option.maxFes        = option.D*5000;   %����������
        option.numAgent = round(option.D*18);
    else
        option.maxFes        = ceil(sqrt(option.D)*10000);   %����������
        option.numAgent = round(sqrt(option.D)*18);
    end
    option.maxFes=10000;
    option.numAgent=100;
    option.maxIteration  = floor(option.maxFes/option.numAgent); % Maximum number of iterations
    %% ָ���������� (Specify the Problem to Solve)
    funno = temp(1);
    temp(1) = [];
    fname=str2func('funcEval');
    %% ��ʼ����Ⱥ
    x=rand(option.numAgent,dim)*(ub-lb)+lb;
    y= funcEval(x',funno,data);
    %% ��ʼ�� 
    recording=zeros(option.maxFes,1);
    v=randn(size(x));
    %% ���¼�¼
    [y_g,position]=min(y);
    x_g=x(position(1),:);
    y_p=y;
    x_p=x;
    recording(1)=y_g;
    
    option.w_pso=0.8;
    option.c1_pso=2;
    option.c2_pso=2;
    w_pso=option.w_pso;
    c1_pso=option.c1_pso;
    c2_pso=option.c2_pso;
    LB=option.lb;
    UB=option.ub;
    numAgent=option.numAgent;
    FES = numAgent; % ��Ӧ���������� (Function evaluations counter)
    FES0=1;
    %% ��ʼ����
    for iter=1:option.maxIteration
        %disp(['PSO,iter:',num2str(iter),',minFit:',num2str(y_g)])
        %% ��¼����ֵ (Record Best Fitness)
        recording(FES0:FES) = y_g;
        FES0 = FES+1;
        %% ����
        r1=rand(numAgent,dim);
        r2=rand(numAgent,dim);
        for i=1:numAgent
            v(i,:)=w_pso*v(i,:)+c1_pso*r1(i,:).*(x_g-x(i,:))+c2_pso*r2(i,:).*(x_p(i,:)-x(i,:));
            x(i,:)=x(i,:)+v(i,:);
            x(i,x(i,:)<LB)=LB(x(i,:)<LB);
            x(i,x(i,:)>UB)=UB(x(i,:)>UB);
            y(i)= funcEval(x(i,:)',funno,data);
            if y(i)<y_p(i)
                y_p(i)=y(i);
                x_p(i,:)=x(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
    end
    %% ��¼����ֵ (Record Best Fitness)
    recording(FES0:FES) = y_g;
    bestY=y_g;
    bestX=x_g;
end