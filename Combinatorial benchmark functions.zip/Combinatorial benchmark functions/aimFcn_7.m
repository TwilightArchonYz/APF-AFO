function [y,result]=aimFcn_7(x,data)
    x=reshape(x,data.KN,data.numM);
    flag=zeros(data.numN,1);
    nowO=ones(data.numN,1);
    nowT_N=data.ST;
    nowT_M=zeros(data.numM,1);
    recording=[];
    while 1
        p=find(flag==0);
        if isempty(p)
            break;
        end
        pri=zeros(length(p),data.numM );
        gapT_M=zeros(length(p),data.numM );
        needT=zeros(length(p),data.numM );
        for i=1:length(p)
            noN=p(i);
            noO=nowO(noN);
            pp=find(data.T(:,1)==noN & data.T(:,2)==noO);
            for noM=1:data.numM 
                ST_N=nowT_N(noN);
                ST_M=nowT_M(noM);
                ST=max(ST_N,ST_M);
                gapT_M(i,noM)=ST-ST_M;
                needT(i,noM)=data.T(pp,noM+2);
                pri(i,noM)=x(pp,noM);
            end
        end
        temp1=myMapminmax(gapT_M);
        temp2=myMapminmax(needT);
        temp3=myMapminmax(pri);
        temp=temp1+temp2+temp3;
        [p1,p2]=find(temp==min(min(temp)));
        noN = p(p1(1));
        noM = p2(1);
        ST_N=nowT_N(noN);
        ST_M=nowT_M(noM);
        ST=max(ST_N,ST_M);
        noO=nowO(noN);
        p=find(data.T(:,1)==noN & data.T(:,2)==noO);
        needT=data.T(p,noM+2);
        ET=ST+needT;
        recording=[recording;noN,noO,noM,ST,ET];
        nowO(noN)=nowO(noN)+1;
        nowT_N(noN)=ET;
        nowT_M(noM)=ET;
        if nowO(noN)>data.numK(noN)
            flag(noN)=1;
        end
        
    end
    y=max(recording(:,5));
    result.recording=recording;
    result.path=path;
end