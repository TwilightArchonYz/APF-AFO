function [y,result]=aimFcn_2(x,data)
        S=data.node(1,:);
        flag=zeros(data.numNode,1);
        nowP=1;
        path=nowP;
        sumD=0;
        while 1
            p=find(flag==0);
            if isempty(p)
                break;
            end
            D=zeros(1,length(p));
            pri=zeros(1,length(p));
            for i=1:length(p)
                noN=p(i);
                D(i)=data.D(nowP,noN);
                pri(i)=x(noN);
            end
            temp1=myMapminmax(D);
            temp2=myMapminmax(pri);
            temp=temp2;
            [~,ind]=min(temp);
            nextP=p(ind);
            path=[path,nextP];
            sumD=sumD+data.D(nowP,nextP);
            nowP=nextP;
            flag(nowP)=1;
        end
        nextP=1;
        path=[path,nextP];
        sumD=sumD+data.D(nowP,nextP);
        y=sumD;
        result.path=path;
        result.y=y;
end