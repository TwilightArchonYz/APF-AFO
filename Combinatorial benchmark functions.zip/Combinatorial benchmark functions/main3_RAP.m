clear all
close all
%% 实验参数
repNum=100;
rng('default')
mainSeed = 1;
% 创建一个随机数流对象
stream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end


noPro0=[17,18,19,20,21,22,23,24]; %TSP,车辆配送，栅格路径规划，无人机路径规划
VRmin=0;
VRmax=1;
%%
%parpool(6);
algorithms=[{@func_PSO}];
%%
for i=1:length(noPro0)
    rng(1)
    disp(num2str(i))
    noPro=noPro0(i);
    data=[];
    if noPro==17
        data.numC=5;
        data.numNode=25+data.numC;
        data.node=rand(data.numNode,2);
        data.demand=5+10*rand(data.numNode,1);
        data.demand(1:data.numC)=0;
        data.DD=pdist2(data.node,data.node);
        data.maxCap=60;
        Dimension=data.numC*data.numNode;
    elseif noPro==18
        data.numC=5;
        data.numNode=50+data.numC;
        data.node=rand(data.numNode,2);
        data.demand=5+10*rand(data.numNode,1);
        data.demand(1:data.numC)=0;
        data.DD=pdist2(data.node,data.node);
        data.maxCap=120;
        Dimension=data.numC*data.numNode;
    elseif noPro==19
        data.numC=10;
        data.numNode=50+data.numC;
        data.node=rand(data.numNode,2);
        data.demand=5+10*rand(data.numNode,1);
        data.demand(1:data.numC)=0;
        data.DD=pdist2(data.node,data.node);
        data.maxCap=60;
        Dimension=data.numC*data.numNode;
    elseif noPro==20
        data.numC=10;
        data.numNode=100+data.numC;
        data.node=rand(data.numNode,2);
        data.demand=5+10*rand(data.numNode,1);
        data.demand(1:data.numC)=0;
        data.DD=pdist2(data.node,data.node);
        data.maxCap=120;
        Dimension=data.numC*data.numNode;
    elseif noPro==21
        data=data1{1};
        Dimension=data.numC*data.numNode;
    elseif noPro==22
        data=data1{2};
        Dimension=data.numC*data.numNode;
    elseif noPro==23
        data=data1{3};
        Dimension=data.numC*data.numNode;
    elseif noPro==24 
        data=data1{4};
        Dimension=data.numC*data.numNode;
    end
    data1{i}=data;
    tempX=zeros(length(algorithms),Dimension);
    parfor j=1:length(algorithms)
        tempfile=[noPro];
        % 获取当前迭代的随机数流
        currentStream = seeds{1};
        % 设置当前工作者的随机数流
        RandStream.setGlobalStream(currentStream);
        [tempX(j,:),bestY(i,j),Recording{i,j}] =algorithms{j}(Dimension,VRmin,VRmax,tempfile,data);
        index=find(Recording{i,j}==0);
        index1=find(Recording{i,j}>0);
        Recording{i,j}(index)=min(Recording{i,j}(index1));
    end
    bestX{i}=tempX;
end
