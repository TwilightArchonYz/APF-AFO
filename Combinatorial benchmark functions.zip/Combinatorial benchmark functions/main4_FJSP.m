clear all
close all
%% 实验参数
paraMeters=[10,100,0,0];
%%
repNum=100;
rng('default')
mainSeed = 1;
% 创建一个随机数流对象
stream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end

noPro0=[25,26,27,28,29,30,31,32]; 
VRmin=0;
VRmax=1;
%%
%parpool(6);
algorithms=[{@func_PSO}];
%%
for i=1:length(noPro0)
    rng(1)
    disp(num2str(i))
    noPro=noPro0(i);
    data=[];
    if noPro==25
        data.numM=4;%机器数量范围
        data.numN=ceil(data.numM*2.5); %作业数量
        data.boundK=[ceil(data.numM)/2,ceil(data.numM*1.5)];%工序范围
        data.boundT=[5,10];  
        data.ST=randi(10,data.numN,1);
        
        data.numK=randi(data.numM,data.numN,1)+data.numM;
        data.numKN=sum(data.numK);
        data.T=[];
        for noJ=1:data.numN
            data.numK(noJ)=round(data.boundK(1)+rand*(data.boundK(2)-data.boundK(1)));
            tempT=round(rand(data.numK(noJ),data.numM)*(data.boundT(2)-data.boundT(1)))+data.boundT(1);
            data.T=[data.T;noJ*ones(data.numK(noJ),1),[1:data.numK(noJ)]',tempT];
        end
        data.KN=length(data.T(:,1));
        Dimension=data.KN*data.numM;
    elseif noPro==26
        data.numM=5;%机器数量范围
        data.numN=ceil(data.numM*2.5); %作业数量
        data.boundK=[ceil(data.numM)/2,ceil(data.numM*1.5)];%工序范围
        data.boundT=[5,10];  
        data.ST=randi(10,data.numN,1);
        data.numK=randi(data.numM,data.numN,1)+data.numM;
        data.numKN=sum(data.numK);
        data.ST=randi(10,data.numN,1);
        data.T=[];
        for noJ=1:data.numN
            data.numK(noJ)=round(data.boundK(1)+rand*(data.boundK(2)-data.boundK(1)));
            tempT=round(rand(data.numK(noJ),data.numM)*(data.boundT(2)-data.boundT(1)))+data.boundT(1);
            data.T=[data.T;noJ*ones(data.numK(noJ),1),[1:data.numK(noJ)]',tempT];
        end
        data.KN=length(data.T(:,1));
        Dimension=data.KN*data.numM;
    elseif noPro==27
        data.numM=6;%机器数量范围
        data.numN=ceil(data.numM*2.5); %作业数量
        data.boundK=[ceil(data.numM)/2,ceil(data.numM*1.5)];%工序范围
        data.boundT=[5,10];  
        data.ST=randi(10,data.numN,1);
        data.numK=randi(data.numM,data.numN,1)+data.numM;
        data.numKN=sum(data.numK);
        data.T=[];
        for noJ=1:data.numN
            data.numK(noJ)=round(data.boundK(1)+rand*(data.boundK(2)-data.boundK(1)));
            tempT=round(rand(data.numK(noJ),data.numM)*(data.boundT(2)-data.boundT(1)))+data.boundT(1);
            data.T=[data.T;noJ*ones(data.numK(noJ),1),[1:data.numK(noJ)]',tempT];
        end
        data.KN=length(data.T(:,1));
        Dimension=data.KN*data.numM;
    elseif noPro==28
        data.numM=8;%机器数量范围
        data.numN=ceil(data.numM*2.5); %作业数量
        data.boundK=[ceil(data.numM)/2,ceil(data.numM*1.5)];%工序范围
        data.boundT=[5,10];  
        data.ST=randi(10,data.numN,1);
        data.numK=randi(data.numM,data.numN,1)+data.numM;
        data.numKN=sum(data.numK);
        data.T=[];
        for noJ=1:data.numN
            data.numK(noJ)=round(data.boundK(1)+rand*(data.boundK(2)-data.boundK(1)));
            tempT=round(rand(data.numK(noJ),data.numM)*(data.boundT(2)-data.boundT(1)))+data.boundT(1);
            data.T=[data.T;noJ*ones(data.numK(noJ),1),[1:data.numK(noJ)]',tempT];
        end
        data.KN=length(data.T(:,1));
        Dimension=data.KN*data.numM;
    elseif noPro==29
        data=data1{1};
        Dimension=data.KN*data.numM;
    elseif noPro==30
        data=data1{2};
        Dimension=data.KN*data.numM;
    elseif noPro==31
        data=data1{3};
        Dimension=data.KN*data.numM;
    elseif noPro==32 
        data=data1{4};
        Dimension=data.KN*data.numM;
    end
    data1{i}=data;
    tempX=zeros(length(algorithms),Dimension);
    for j=1:length(algorithms)
        tempfile=[noPro];
        % 获取当前迭代的随机数流
        currentStream = seeds{1}; %OK
        % 设置当前工作者的随机数流
        RandStream.setGlobalStream(currentStream);
        [tempX(j,:),bestY(i,j),Recording{i,j}] =algorithms{j}(Dimension,VRmin,VRmax,tempfile,data);
        index=find(Recording{i,j}==0);
        index1=find(Recording{i,j}>0);
        Recording{i,j}(index)=min(Recording{i,j}(index1));
    end
    bestX{i}=tempX;

end
