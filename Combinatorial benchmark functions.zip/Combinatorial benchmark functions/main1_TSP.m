clear all
close all
%% 实验参数
repNum=100;
rng('default')
mainSeed = 1;
% 创建一个随机数流对象
stream = RandStream('mt19937ar', 'Seed', mainSeed);
seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end


noPro0=[1,2,3,4,5,6,7,8]; %TSP,车辆配送，栅格路径规划，无人机路径规划
VRmin=0;
VRmax=1;
%%
%parpool(6);
algorithms=[{@func_PSO}];

%%
for i=1:8
    rng(1)
    disp(num2str(i))
    noPro=noPro0(i);
    if noPro==1
        numNode=25;
        Dimension=numNode;
        data.node=rand(numNode,2);
        data.D=pdist2(data.node,data.node);
        data.numNode=numNode;
    elseif noPro==2
        numNode=50;
        Dimension=numNode;
        data.node=rand(numNode,2);
        data.D=pdist2(data.node,data.node);
        data.numNode=numNode;  
    elseif noPro==3
        numNode=75;
        Dimension=numNode;
        data.node=rand(numNode,2);
        data.D=pdist2(data.node,data.node);
        data.numNode=numNode;
    elseif noPro==4
        numNode=100;
        Dimension=numNode;
        data.node=rand(numNode,2); 
        data.D=pdist2(data.node,data.node);
        data.numNode=numNode;
    elseif noPro==5
        numNode=25;
        Dimension=numNode;
        data=data1{1};
    elseif noPro==6
        numNode=50;
        Dimension=numNode;
        data=data1{2};
    elseif noPro==7
        numNode=75;
        Dimension=numNode;
        data=data1{3};
    elseif noPro==8
        numNode=100;
        Dimension=numNode;
        data=data1{4}; 
    end
    data1{i}=data;
    tempX=zeros(length(algorithms),Dimension);
    parfor j=1:length(algorithms)
        tempfile=[noPro];
        % 获取当前迭代的随机数流
        currentStream = seeds{1};
        % 设置当前工作者的随机数流
        RandStream.setGlobalStream(currentStream);
        [tempX(j,:),bestY(i,j),Recording{i,j}] =algorithms{j}(Dimension,VRmin,VRmax,tempfile,data);
        index=find(Recording{i,j}==0);
        index1=find(Recording{i,j}>0);
        Recording{i,j}(index)=min(Recording{i,j}(index1));
    end
    bestX{i}=tempX;
end
