function [y,x]=funcEval(x,noPro,data)
    %global data
    if noPro(1)<=4
        %disp(x)
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_1(x(:,i),data);
        end
    elseif noPro(1)>4 && noPro(1)<=8
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_2(x(:,i),data);
        end
    elseif noPro(1)>8 && noPro(1)<=12
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_3(x(:,i),data);
        end
    elseif noPro(1)>12 && noPro(1)<=16
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_4(x(:,i),data);
        end
    elseif noPro(1)>16 && noPro(1)<=20
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_5(x(:,i),data);
        end
    elseif noPro(1)>20 && noPro(1)<=24
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_6(x(:,i),data);
        end
    elseif noPro(1)>24 && noPro(1)<=28
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_7(x(:,i),data);
        end
    elseif noPro(1)>28 && noPro(1)<=32
        for i=1:length(x(1,:))
            y(i,1)=aimFcn_8(x(:,i),data);
        end
    end
end