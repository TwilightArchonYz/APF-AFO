function [y,result]=aimFcn_5(x,data)
    x=reshape(x,data.numC,data.numNode);
    flag=zeros(data.numNode,1);
    flag(1:data.numC)=1;
    Cap=zeros(data.numC,1);
    recording=[];
    while 1
        p=find(flag==0);
        if isempty(p)
            break;
        end
        D=zeros(length(p),data.numC);
        pri=D;
        for i=1:length(p)
            for noC=1:data.numC
                noN=p(i);
                D(i,noC)=data.DD(noC,noN);
                need=data.demand(noN);
                if Cap(noC)+need>data.maxCap
                    pri(i,noC)=inf;
                else
                    pri(i,noC)=x(noC,noN);
                end
            end
        end
        temp1=myMapminmax(D);
        temp2=myMapminmax(pri);
        temp=temp2;
        [p1,p2]=find(temp==min(min(temp)));
        noN=p(p1(1));
        noC=p2(1);
        D=data.DD(noC,noN);
        need=data.demand(noN);
        recording=[recording;noC,noN,D,need];
        Cap(noC)=Cap(noC)+need;
        flag(noN)=1;
    end
    y=sum(recording(:,3));
    result.recording=recording;
    result.path=path;
end