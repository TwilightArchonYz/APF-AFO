function indexNita=get_IndexNita(memory_nita,pop_size)
    numM_nita=length(memory_nita);
    if ~isempty(memory_nita)
        indexNita=randi(numM_nita,pop_size,1);
    else
        indexNita=[];
    end
end