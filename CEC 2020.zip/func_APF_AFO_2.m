function [gbest,gbestval,recording]=func_APF_AFO_2(dim,lb,ub,temp)
%% 通用参数 (General Parameters)
option.ub            = ub*ones(1,dim);  % Upper bound for all dimensions
option.lb            = lb*ones(1,dim);  % Lower bound for all dimensions
option.D             = dim;             % Dimensionality of the problem
option.maxFes        = option.D*10000;  % Maximum function evaluations
option.init_numAgent = round(option.D*18); % Initial number of agents
option.min_numAgent  = 4;               % Minimum number of agents
option.maxIteration  = ceil(2*option.maxFes/(option.init_numAgent+option.min_numAgent)); % Maximum number of iterations
option.numPop        = 2;               % Number of populations
numAgent             = option.init_numAgent;
lu                   = [option.lb; option.ub]; % Lower and upper bound matrix

%% 指定求解的问题 (Specify the Problem to Solve)
funno = temp(1);
temp(1) = [];
fname = str2func('cec20_func');

%% APF参数 (APF Parameters)
p_apf = [1,1];
nita0 = temp(1:2);
min_p_apf = temp(3:4);

%% 其他参数 (Other Parameters)
numM1 = 1.4;            % Memory size
numM2 = 5;              % Memory size
rate_leader = 0.25;     % Proportion of leaders
min_rate_leader = 0.1;  % Minimum proportion of leaders
gama0 = [0.1];          % Initial value for a specific parameter
sp_v = 1;               % Success probability for velocity
%% 主种群初始化 (Main Population Initialization)
pop_x = repmat(lu(1, :), numAgent, 1) + rand(numAgent, option.D) .* (repmat(lu(2, :) - lu(1, :), numAgent, 1));
pop_y = feval(fname, pop_x', funno)'; % 计算适应度值 (Evaluate fitness values)
[best_y,no] = min(pop_y); % 找到当前最优解 (Find the best solution)
best_x = pop_x(no,:);
v_pre = pop_x * 0; % 速度初始化 (Initialize velocity)

%% 辅助种群初始化 (Auxiliary Population Initialization)
numAgent_2 = 4 + floor(3 * log(dim));
index = randperm(length(pop_y), numAgent_2); % 随机选择个体 (Randomly select individuals)
pop_x_2 = pop_x(index,:);
pop_y_2 = pop_y(index,:);
[~,S] = sort(pop_y_2); % 按适应度值排序 (Sort based on fitness)
pop_x_2 = pop_x_2(S,:);
pop_y_2 = pop_y_2(S,:);

setting = [];
bnd = [];
fitness = [];
[setting] = init_cma_par(setting, pop_x_2, dim, numAgent_2); % 初始化 CMA-ES 参数 (Initialize CMA-ES parameters)

%% 计数器 (Counters)
FES = numAgent; % 适应度评估计数 (Function evaluations counter)
iter = 0;       % 迭代次数 (Iteration counter)
count = 0;      % 其他计数器 (General counter)

%% 记忆池 (Memory Pool)
pool_nita = 0.5 .* ones(numM2, 1); % 存储 nita 参数 (Memory for nita)
pool_cr = 0.8 .* ones(numM2, 1);   % 存储交叉概率 (Memory for crossover rate)
pool_gama = 1 .* ones(numM2, 1);   % 存储 gama 参数 (Memory for gama)
pool_pos = 1; % 记忆池索引 (Index in memory pool)

pool_nita1 = [];
pool_nita2 = [];
pop_x_m = []; % 存储的解 (Stored solutions)
pop_y_m = []; % 存储的适应度值 (Stored fitness values)


%% 记录收敛曲线
recording=zeros(1,option.maxFes);
%% main loop
%recording(1)=min(pop_y);
FES0=1;
while FES <= option.maxFes
    iter = iter + 1; % 迭代计数 (Iteration counter)

    %% 记录最优值 (Record Best Fitness)
    recording(FES0:FES) = best_y;
    FES0 = FES;

    %% 参数更新基准数据 (Parameter Update Reference Data)
    mem_rand_index = ceil(numM2 * rand(numAgent, 1)); % 随机索引 (Randomly select indices)
    mu_nita = pool_nita(mem_rand_index); % 选择对应的 nita 值 (Select corresponding nita values)
    mu_cr = pool_cr(mem_rand_index); % 选择对应的交叉率 (Select corresponding crossover rate)
    mask = mem_rand_index == numM2; % 确保某些情况下的特殊处理 (Ensure special handling for certain cases)
    mu_nita(mask) = 0.9;
    mu_cr(mask) = 0.9;

    %% 交叉率 (Crossover Rate)
    cr = normrnd(mu_cr, 0.1); % 服从正态分布的交叉率 (Crossover rate following normal distribution)
    term_pos = mu_cr == -1;
    cr(term_pos) = 0;
    cr = min(cr, 1);
    cr = max(cr, 0);

    %% 权重 (Weight Calculation)
    nita = mu_nita + 0.1 * tan(pi * (rand(numAgent, 1) - 0.5)); % 使用 Cauchy 分布扰动 (Perturb using Cauchy distribution)
    pos = find(nita <= 0);
    while ~isempty(pos)
        nita(pos) = mu_nita(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5)); % 重新计算非正值 (Recompute negative values)
        pos = find(nita <= 0);
    end
    nita = min(nita, 1);

    %% 更新用的数据准备 (Prepare Data for Update)
    r0 = 1 : numAgent;
    popAll = [pop_x; pop_x_m]; % 合并当前种群与存档 (Combine current population and archive)
    [r1, r2] = gnR1R2(numAgent, size(popAll, 1), r0); % 生成随机索引 (Generate random indices)

    %% 选择最优个体 (Select Best Individuals)
    [~, sorted_index] = sort(pop_y); % 按适应度值排序 (Sort population by fitness)
    p_best_rate = (rate_leader - min_rate_leader) * FES / option.maxFes + min_rate_leader; % 计算头领比例 (Compute leader proportion)
    pNP = round(p_best_rate * numAgent); % 计算精英个体数 (Compute elite individual count)
    randindex = ceil(rand(numAgent, 1) .* pNP); % 从最优 pNP 个体中随机选择 (Randomly select from the top pNP individuals)
    randindex = max(1, randindex); % 确保索引大于 0 (Ensure index is at least 1)
    pbest = pop_x(sorted_index(randindex), :); % 选取 pbest 个体 (Select pbest individuals)
    pbest_Y = pop_y(sorted_index(randindex), :);

    %% 计算种群距离 (Compute Population Distances)
    popAll_Y = [pop_y; pop_y_m]; % 适应度值集合 (Fitness value set)
    pop_Y = pop_y;
    D1 = pdist2(pop_x, pbest); % 计算当前种群到 pbest 的距离 (Distance between population and pbest)
    D2 = pdist2(pop_x, popAll); % 计算当前种群到所有解的距离 (Distance between population and all solutions)

    %% 记忆池索引 (Memory Pool Index)
    newNita1 = [];
    newNita2 = [];
    indexNita1 = get_IndexNita(pool_nita1, numAgent);
    indexNita2 = get_IndexNita(pool_nita2, numAgent);
    indexGama = get_IndexNita(pool_gama, numAgent);

    %% 选择最近的个体 (Select Closest Individuals)
    DD = pdist2(best_x, pop_x); % 计算当前最优解与种群中个体的距离 (Compute distance between best solution and population)
    [~, S] = sort(DD); % 按距离排序 (Sort by distance)
    index_pop1 = S(1:ceil(0.5 * numAgent)); % 选择一半最近的个体 (Select the closest 50% individuals)

    %% 更新 (Update)
    newGama = [];                         % 重置 newGama (Reset newGama)
    newX = zeros(numAgent, option.D);       % 初始化新解矩阵 (Initialize new solution matrix)
    for i = 1:numAgent
        %% V1
        [Frep1, newNita1] = getF_rep2(pbest_Y, pop_Y, pbest, pop_x, p_apf(1), i, i, nita0(1), pool_nita1, indexNita1, newNita1, D1, numAgent, option.D);
        V1 = pbest(i,:) - pop_x(i,:) + Frep1; % 计算 V1 (Compute V1 as the difference to pbest plus adjustment)

        %% V2
        if ismember(i, index_pop1)
            [Frep2, newNita2] = getF_rep2(popAll_Y, pop_Y, popAll, pop_x, p_apf(2), r1(i), r2(i), nita0(2), pool_nita2, indexNita2, newNita2, D2, numAgent, option.D);
            V2 = pop_x(r1(i), :) - popAll(r2(i), :) + Frep2; % 对于部分个体，使用不同的参照数据 (For selected individuals, use alternative reference data)
        else
            [Frep2, newNita2] = getF_rep2(popAll_Y, popAll_Y, popAll, popAll, p_apf(2), r1(i), r2(i), nita0(2), pool_nita2, indexNita2, newNita2, D2, numAgent, option.D);
            V2 = pop_x(r1(i), :) - popAll(r2(i), :) + Frep2; % 其他个体的 V2 (V2 for the remaining individuals)
        end

        %% V3
        if rand < sp_v
            gama(i,1) = get_coefficients(pool_gama, numAgent, indexGama, gama0, i);
            V3 = gama(i,1) * v_pre(i,:);  % 根据历史速度进行调整 (Adjust based on previous velocity)
            newGama = [newGama; gama(i,1), i];
        else
            V3 = 0;
        end
        newX(i,:) = pop_x(i,:) + nita(i) * (V1 + V2 + V3); % 更新个体位置 (Update individual position)
    end

    %% 约束边界处理 (Boundary Constraint Handling)
    LB = repmat(option.lb, numAgent, 1);
    UB = repmat(option.ub, numAgent, 1);
    index = find(newX < LB);
    newX(index) = LB(index) + LB(index) - newX(index);
    index = find(newX > UB);
    newX(index) = UB(index) + UB(index) - newX(index);
    index = find(newX > UB);
    newX(index) = UB(index);
    index = find(newX < LB);
    newX(index) = LB(index);


    %% 交叉
    mask = rand(numAgent, option.D) > cr(:, ones(1, option.D)); % mask用于指示哪些ui元素来自子代 (mask indicates which elements of ui come from the offspring)
    rows = (1 : numAgent)';
    cols = floor(rand(numAgent, 1) * option.D) + 1; % 选择一个维度确保该位置的基因不来自子代 (choose one dimension where the gene is forced to come from the parent)
    jrand = sub2ind([numAgent option.D], rows, cols);
    mask(jrand) = false;
    ui = newX;
    ui(mask) = pop_x(mask); % 利用mask进行交叉操作 (Perform crossover based on mask)

    %% 评价
    %children_pop_y = benchmark_func(ui, problem);
    children_pop_y = feval(fname, ui', funno)'; % 评价子代适应度 (Evaluate offspring fitness)
    dif = abs(pop_y - children_pop_y); % 计算适应度差 (Compute fitness difference)

    %% 参数保存
    I = (pop_y > children_pop_y); % 标记出适应度改善的个体 (Identify individuals with improved fitness)
    goodCR = cr(I == 1);         % 保存成功的交叉率 (Store successful crossover rates)
    goodF = nita(I == 1);        % 保存成功的nita参数 (Store successful nita values)
    dif_val = dif(I == 1);       % 保存适应度改善幅度 (Store fitness improvements)

    % 更新参数池 (Update parameter pools)
    [pool_nita1, p_apf(1)] = get_P_Apf(p_apf(1), newNita1, I, pool_nita1, numAgent, min_p_apf(1));
    [pool_nita2, p_apf(2)] = get_P_Apf(p_apf(2), newNita2, I, pool_nita2, numAgent, min_p_apf(2));
    [pool_gama, sp_v] = get_P_Apf1(sp_v, newGama, I, pool_gama, numAgent, 0, numM2);

    % 更新记忆池 (Update the archive)
    pop_x_m = [pop_x(I == 1, :); pop_x_m];
    pop_y_m = [pop_y(I == 1, :); pop_y_m];
    numPopM = ceil(numAgent * numM1);
    if length(pop_y_m) > numPopM
        [~, ind] = unique(pop_x_m, 'rows'); % 去除重复解 (Remove duplicate solutions)
        pop_x_m = pop_x_m(ind, :);
        pop_y_m = pop_y_m(ind, :);
        if length(pop_y_m) > numPopM
            rndpos = randperm(length(pop_y_m)); % 随机排列 (Random permutation)
            ind = rndpos(1 : numPopM);
            pop_x_m = pop_x_m(ind, :);
            pop_y_m = pop_y_m(ind, :);
        end
    end

    % 更新主种群 (Update main population)
    [pop_y, I] = min([pop_y, children_pop_y], [], 2); % 选择较优个体 (Select the better individual for each position)
    pop_x(I == 2, :) = ui(I == 2, :); % 替换劣解 (Replace with offspring when improved)
    pop_y(I == 2, :) = children_pop_y(I == 2, :);
    num_success_params = numel(goodCR); % 记录成功参数个数 (Record the number of successful parameters)

    %% 参数更新 (Parameter Update)
    if num_success_params > 0
        sum_dif = sum(dif_val);  % 计算适应度差值之和 (Sum of fitness differences)
        dif_val = dif_val / sum_dif;  % 归一化适应度差值 (Normalize fitness differences)
        pool_nita(pool_pos) = ((dif_val' * (goodF .^ 2)) / (dif_val' * goodF) + pool_nita(pool_pos)) / 2; % 更新缩放因子的记忆 (Update memory of scaling factor)

        %% 更新交叉率的记忆 (Update memory of crossover rate)
        if max(goodCR) == 0 || pool_cr(pool_pos) == -1
            pool_cr(pool_pos) = 0;  % 如果交叉率为零或未设置，则设为零 (Set to zero if crossover rate is zero or unset)
        else
            pool_cr(pool_pos) = ((dif_val' * (goodCR .^ 2)) / (dif_val' * goodCR) + pool_cr(pool_pos)) / 2; % 更新交叉率 (Update crossover rate)
        end
        pool_pos = pool_pos + 1;  % 更新池的位置 (Update position in the pool)
        if pool_pos > numM2
            pool_pos = 1;  % 循环回池的起始位置 (Wrap around to the start of the pool)
        end
    end

    %% 历史最优解 (Update Best Historical Solution)
    [best_y0, no] = min(pop_y);  % 找到当前最优解 (Find current best solution)
    best_x0 = pop_x(no, :);      % 记录当前最优解的位置 (Store current best solution position)
    if best_y > best_y0
        best_y = best_y0;  % 更新全局最优值 (Update global best value)
        best_x = best_x0;  % 更新全局最优解 (Update global best solution)
    end

    %% 更新FES (Update FES)
    FES = FES + numAgent;  % 增加评价次数 (Increase function evaluations)

    %% 辅助种群搜索 (Auxiliary Population Search)
    D = zeros(1, 2);
    Y = zeros(1, 2);
    D(1) = mean(pdist2(best_x, pop_x));           % 计算当前最优解与种群的平均距离 (Compute mean distance between best solution and population)
    D(2) = mean(pdist2(pop_x_2(1, :), pop_x_2));  % 计算辅助种群内的距离 (Compute mean distance within the auxiliary population)
    Y(1) = best_y;                                % 当前最优适应度 (Current best fitness)
    Y(2) = pop_y_2(1, :);                         % 辅助种群的最优适应度 (Best fitness of auxiliary population)
    P = myMapminmax(D) + myMapminmax(1 - Y);      % 归一化距离和适应度 (Normalize distances and fitness)
    P = P / sum(P);  % 归一化 (Normalize)

    if count > 10  % 当计数大于 10 时 (If count exceeds 10)
        count = 0;  % 重置计数器 (Reset counter)
        [~, noP] = max(P);  % 选择具有最大概率的行动 (Select the action with maximum probability)
        if noP == 1
            tempX = [pop_x];
            tempY = [pop_y];
            index = randperm(length(tempY), min(length(tempY), numAgent_2));  % 随机选择个体 (Randomly select individuals)
            numAgent_2 = length(index);
            pop_x_2 = tempX(index, :);
            pop_y_2 = tempY(index, :);
            [~, S] = sort(pop_y_2);  % 按适应度值排序 (Sort by fitness)
            pop_x_2 = pop_x_2(S, :);
            pop_y_2 = pop_y_2(S, :);
            [setting] = init_cma_par(setting, pop_x_2, option.D, numAgent_2);  % 初始化 CMA-ES 参数 (Initialize CMA-ES parameters)
        end
        flag = 0;
    end

    if rand < max(0.05, P(2))  % 如果满足条件，则进行探索 (If condition is met, perform exploration)
        probSC = 1 / 2 .* ones(1, 2);  % 设置探索概率 (Set exploration probability)
        preBestY_2 = min(pop_y_2);  % 记录辅助种群的最优适应度 (Record the best fitness of the auxiliary population)
        preBestY = best_y;  % 记录当前最优适应度 (Record the current best fitness)

        [pop_x_2, pop_y_2, setting, best_y, best_x, bnd, fitness, FES] = ...
            Scout(pop_x_2, pop_y_2, probSC, setting, iter, best_y, best_x, fitness, bnd, ...
            option.lb, option.ub, dim, numAgent_2, FES, funno, option.maxFes);

        pop_y_2 = pop_y_2';
        count = count + 1;
        if preBestY_2 < min(pop_y_2)
            count = count + 1;  
        else
            count = 0;          
        end
        if preBestY > best_y
            [~, S] = sort(pop_y);  % 根据适应度排序 (Sort by fitness)
            pop_x(S(end), :) = best_x;  % 更新种群 (Update population)
            pop_y(S(end), :) = best_y;
        end
    end

    %% 种群削减 (Population Reduction)
    numAgent_g1 = round((option.min_numAgent - option.init_numAgent) * min(1, FES / (0.95 * option.maxFes)) + option.init_numAgent);
    [~, sorted_index] = sort(pop_y);
    if numAgent_g1 < numAgent
        numAgent = numAgent_g1;
        pop_x = pop_x(sorted_index(1:numAgent), :);  % 删除较差的个体 (Remove the worst individuals)
        pop_y = pop_y(sorted_index(1:numAgent), :);
    end

end
[gbestval,ll] = min(pop_y);
gbest = pop_x(ll,:);
end

function [r1, r2] = gnR1R2(NP1, NP2, r0)

% gnA1A2 generate two column vectors r1 and r2 of size NP1 & NP2, respectively
%    r1's elements are choosen from {1, 2, ..., NP1} & r1(i) ~= r0(i)
%    r2's elements are choosen from {1, 2, ..., NP2} & r2(i) ~= r1(i) & r2(i) ~= r0(i)
%
% Call:
%    [r1 r2 ...] = gnA1A2(NP1)   % r0 is set to be (1:NP1)'
%    [r1 r2 ...] = gnA1A2(NP1, r0) % r0 should be of length NP1
%
% Version: 1  Date: 2020/08/11
% Written by zhenyu wang (tsingke123@163.com)

NP0 = length(r0);
for i = 1:NP0
    temp = randperm(NP2);
    r2(i) = temp(1);
    k=2;
    while temp(k) > NP1
        k = k+1;
    end
    r1(i) = temp(k);
    if(r2(i) == r0(i))
        r2(i) = temp(k+1);
    end
    if(r1(i) == r0(i))
        k=k+1;
        while temp(k) > NP1
            k = k+1;
        end
        r1(i) = temp(k);
    end
end
end
%%
function [setting]= init_cma_par(setting, EA_2, n, n2)
%% So, mean(EA_2) does not violate the initialization condition in the competition
setting.xmean = mean(EA_2);
setting.xmean=setting.xmean';
setting.insigma=0.3;
setting.sigma = setting.insigma;


setting.sigma = max(setting.insigma);              % overall standard deviation
setting.pc = zeros(n,1); setting.ps = zeros(n,1);  % evolution paths for setting.C and setting.sigma

if length(setting.insigma) == 1
    setting.insigma = setting.insigma * ones(n,1) ;
end
setting.diagD = setting.insigma/max(setting.insigma);      % diagonal matrix D defines the scaling
setting.diagC = setting.diagD.^2;
setting.B = eye(n,n);                      % setting.B defines the coordinate system
setting.BD = setting.B.*repmat(setting.diagD',n,1);        % setting.B*D for speed up only
setting.C = diag(setting.diagC);                   % covariance matrix == setting.BD*(setting.BD)'
setting.D = ones(n,1);
setting.chiN=n^0.5*(1-1/(4*n)+1/(21*n^2));  % expectation of
setting.mu = ceil(n2/2);               % number of parents/points for recombination
% setting.mu = n2;
setting.weights = log(max(setting.mu, n/2) + 1/2)-log(1:setting.mu)'; % muXone array for weighted recombination setting.mu = floor(setting.mu);
setting.mueff=sum(setting.weights)^2/sum(setting.weights.^2); % variance-effective size of setting.mu
setting.weights = setting.weights/sum(setting.weights);     % normalize recombination setting.weights array

% Strategy parameter setting: Adaptation
setting.cc = (4 + setting.mueff/n) / (n+4 + 2*setting.mueff/n); % time constant for cumulation for setting.C
setting.cs = (setting.mueff+2) / (n+setting.mueff+3);  % t-const for cumulation for setting.sigma control
setting.ccov1 = 2 / ((n+1.3)^2+setting.mueff);    % learning rate for rank-one update of setting.C
setting.ccovmu = 2 * (setting.mueff-2+1/setting.mueff) / ((n+2)^2+setting.mueff);  % and for rank-setting.mu update
setting.damps = 0.5 + 0.5*min(1, (0.27*n2/setting.mueff-1)^2) + 2*max(0,sqrt((setting.mueff-1)/(n+1))-1) + setting.cs; % damping for setting.sigma

setting.xold =  setting.xmean;
end

function[ x, fitx,setting,bestold,bestx,bnd,fitness,current_eval] = ...
    Scout( x, y, prob, setting, iter,bestold,bestx,fitness,bnd,xmin,xmax,n,PopSize,current_eval,noPro,Max_FES)
%% 输入
% x 种群
% y 种群适应度值
% prob 概率
% setting 参数集合
% iter 迭代
% bestold 最优适应度值
% bestx 最优x
%
%% 输出
% stopOnWarnings=0;
% noiseReevals = 0;
fitness.raw = NaN(1, PopSize);% + noiseReevals);
% fitness.raw(PopSize + find(isnan(fitness.raw(1:noiseReevals)))) = NaN;

% arz = randn(n,PopSize);
if rand < prob(1)
    arz = sqrt(pi)*(asin(rand(n,PopSize))+asin(-rand(n,PopSize)));
else
    arz = sqrt(pi)*asin(2*rand(n,PopSize)-1);
end
arx = repmat(setting.xmean, 1, PopSize) + setting.sigma * (setting.BD * arz);

%% ignore handling the boundaries constraints during the first 50% evolutionary process
%%-this is based on our earlier analysis carried out on UMOEAs in 2014.
handle_limit=0.5;
if current_eval >=0.5*Max_FES
    arxvalid =han_boun(arx', xmax, xmin, x,PopSize,2);
    arxvalid=arxvalid';
else
    arxvalid=arx;
end
%% evaluate and update cfe
tempfile=[];

[fitx_new,cons] = funcEval(arxvalid',noPro);   %octave
fitness.raw=fitx_new';
current_eval=current_eval+PopSize; %% increase the fitness evaluations

fitness.sel= fitness.raw ;
[fitness.sel, fitness.idxsel] = sort(fitness.sel);

fitness.raw= fitness.raw(fitness.idxsel);
arxvalid= arxvalid(:, fitness.idxsel);
arx= arx(:, fitness.idxsel);
arz=arz(:, fitness.idxsel);
[~,pos_ro]=min(fitness.raw);

%% record the best value after checking its feasiblity status
if fitness.raw(pos_ro) < bestold && (min(arxvalid(:,pos_ro)))>=-100 && (max(arxvalid(:,pos_ro)))<=100
    bestold=fitness.raw(pos_ro);
    bestx= arxvalid(:,pos_ro)';
end
% if Printing==1
%     res_det= [res_det repmat(bestold,1,PopSize)];
% end

%% setting.weights
setting.weights = fitness.raw(1:setting.mu)';%./sum(fitness.raw(1:setting.mu));
if sum(setting.weights)>1e25
    setting.weights = 1/setting.mu*ones(setting.mu,1);
end
setting.weights = setting.weights/sum(setting.weights);     % normalize recombination setting.weights array
setting.weights = fliplr(setting.weights);
% Calculate new setting.xmean, this is selection and recombination
setting.xold = setting.xmean; % for speed up of Eq. (2) and (3)
cmean =1;% 1/min(max((PopSize-1*n)/2, 1), n);  % == 1/kappa
setting.xmean = (1-cmean) * setting.xold + cmean * arx(:,(1:setting.mu))*setting.weights;
if  current_eval >=handle_limit*Max_FES
    % setting.xmean = xintobounds(setting.xmean, xmin', xmax');
    setting.xmean =han_boun(setting.xmean', xmax, xmin, x(1,:),1,2);
    setting.xmean=setting.xmean';
end
zmean = arz(:,(1:setting.mu))*setting.weights;%==D^-1*setting.B'*(setting.xmean-setting.xold)/setting.sigma
% Cumulation: update evolution paths
setting.ps = (1-setting.cs)*setting.ps + sqrt(setting.cs*(2-setting.cs)*setting.mueff) * (setting.B*zmean);          % Eq. (4)
hsig = norm(setting.ps)/sqrt(1-(1-setting.cs)^(2*iter))/setting.chiN < 1.4 + 2/(n+1);

setting.pc = (1-setting.cc)*setting.pc ...
    + hsig*(sqrt(setting.cc*(2-setting.cc)*setting.mueff)/setting.sigma/cmean) * (setting.xmean-setting.xold);     % Eq. (2)

% Adapt covariance matrix
neg.ccov = 0;  % TODO: move parameter setting upwards at some point
if setting.ccov1 + setting.ccovmu > 0                                                    % Eq. (3)
    arpos = (arx(:,(1:setting.mu))-repmat(setting.xold,1,setting.mu)) / setting.sigma;
    setting.C = (1-setting.ccov1-setting.ccovmu) * setting.C ... % regard old matrix
        + setting.ccov1 * setting.pc*setting.pc' ...     % plus rank one update
        + setting.ccovmu ...             % plus rank setting.mu update
        * arpos * (repmat(setting.weights,1,n) .* arpos');
    % is now O(setting.mu*n^2 + setting.mu*n), was O(setting.mu*n^2 + setting.mu^2*n) when using diag(setting.weights)
    %   for setting.mu=30*n it is now 10 times faster, overall 3 times faster

    setting.diagC = diag(setting.C);
    %     end
end


% Adapt setting.sigma
setting.sigma = setting.sigma * exp(min(1, (sqrt(sum(setting.ps.^2))/setting.chiN - 1) * setting.cs/setting.damps));             % Eq. (5)
% disp([iter norm(setting.ps)/setting.chiN]);

% Update setting.B and D from setting.C

if  (setting.ccov1+setting.ccovmu+neg.ccov) > 0 && mod(iter, 1/(setting.ccov1+setting.ccovmu+neg.ccov)/n/10) < 1
    setting.C=triu(setting.C)+triu(setting.C,1)'; % enforce symmetry to prevent complex numbers
    [setting.B,tmp] = eig(setting.C);     % eigen decomposition, setting.B==normalized eigenvectors
    % effort: approx. 15*n matrix-vector multiplications
    setting.diagD = diag(tmp);

    % limit condition of setting.C to 1e14 + 1
    if min(setting.diagD) <= 0

        setting.diagD(setting.diagD<0) = 0;
        tmp = max(setting.diagD)/1e14;
        setting.C = setting.C + tmp*eye(n,n); setting.diagD = setting.diagD + tmp*ones(n,1);

    end
    if max(setting.diagD) > 1e14*min(setting.diagD)

        tmp = max(setting.diagD)/1e14 - min(setting.diagD);
        setting.C = setting.C + tmp*eye(n,n); setting.diagD = setting.diagD + tmp*ones(n,1);

    end

    setting.diagC = diag(setting.C);
    setting.diagD = sqrt(setting.diagD); % D contains standard deviations now
    % setting.diagD = setting.diagD / prod(setting.diagD)^(1/n);  setting.C = setting.C / prod(setting.diagD)^(2/n);
    setting.BD = setting.B.*repmat(setting.diagD',n,1); % O(n^2)
end % if mod

%% print out final results
x= arxvalid';
fitx= fitness.raw;

end

function x = han_boun (x, xmax, xmin, x2, PopSize,hb)

switch hb;
    case 1 % for DE
        x_L = repmat(xmin, PopSize, 1);
        pos = x < x_L;
        x(pos) = (x2(pos) + x_L(pos)) / 2;

        x_U = repmat(xmax, PopSize, 1);
        pos = x > x_U;
        x(pos) = (x2(pos) + x_U(pos)) / 2;

    case 2 % for CMA-ES
        x_L = repmat(xmin, PopSize, 1);
        pos = x < x_L;
        x_U = repmat(xmax, PopSize, 1);
        x(pos) = min(x_U(pos),max(x_L(pos),2*x_L(pos)-x2(pos)))  ;
        pos = x > x_U;
        x(pos) = max(x_L(pos),min(x_U(pos),2*x_L(pos)-x2(pos)));

end
end