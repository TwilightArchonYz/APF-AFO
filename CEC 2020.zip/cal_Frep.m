function Frep=cal_Frep(nita,nowP,obP,OB_r)
    % 计算斥力
    Dir=obP-nowP;
    D=norm(nowP-obP); 
    if D>OB_r
        Frep=nowP*0;
    else
        Frep=0.5*nita*(1/D-1/OB_r)/D^2*Dir;
    end
end 