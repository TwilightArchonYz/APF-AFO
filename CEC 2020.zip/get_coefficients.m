function  C=get_coefficients(memory_coefficients,numAgent,indexC,C0,i)

        while 1
            if length(memory_coefficients)>numAgent
                C1=memory_coefficients(indexC(i));
                if C1<0
                    C=0;
                else
                    C=0.2*C0+0.8*(C1+randn*0.1);
                end
            else
                C=C0+randn*C0;
            end
            C=min(C,1);
            if C>=0
                break;
            end
        end

end