function [Frep,newNita]=getF_rep2(ep_Y,sp_Y,ep,sp,p_apf,i,k,nita0,memory_nita,indexNita,newNita,DD,pop_size,Dimension)
% 斥力场加一个系数
    % sp 出发位置
    % ep 目标位置
    if ep_Y(k)<sp_Y(i) && rand<p_apf
        % 记忆池里挑选
        if length(memory_nita)>pop_size
            nita1=memory_nita(indexNita(i));
            nita=0.2*nita0+0.8*(nita1+randn*nita1);
        else
            nita=nita0+randn*nita0;
        end
        nita=max(nita,0);
        newNita=[newNita;nita,i];
        %maxD=max(DD(i,:));
        D=DD(i,k);
        OB_r=D/2;
        index=find(DD(i,:)<OB_r & ep_Y'>sp_Y(i));
        if ~isempty(index)
            Frep=zeros(length(index),Dimension);
            for j=1:length(index)
                Frep(j,:)=OB_r*cal_Frep(nita,sp(i,:),ep(index(j),:),OB_r);
            end
            Frep=sum(Frep,1);
        else
            Frep=0;
        end

    else
        Frep=0;
    end
end