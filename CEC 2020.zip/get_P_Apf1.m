function [memory_nita,p_apf]=get_P_Apf1(p_apf,newNita,I,memory_nita,pop_size,min_p_apf,numM)
    if ~isempty(newNita)
        index0=newNita(:,2);
        goodNita=newNita(I(index0)==1,1);
        memory_nita=[memory_nita;goodNita];
        if length(memory_nita)>numM*pop_size
            memory_nita=memory_nita(end-numM*pop_size:end);
        end
        sp=length(goodNita)/length(index0);
        p_apf=max(min_p_apf,0.8*p_apf+0.2*sp);
    end
end