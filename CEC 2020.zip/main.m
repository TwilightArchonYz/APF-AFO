close all
clear all
%global noPro
%%
StrAlgorithm=['APF_AFO'];
%% 范围和问题
VRmin=-100;
VRmax=100;
tempfile=[];
noPro0=1:10;
%% 重复试验次数
repNum=232;
optimum_objs2=zeros(repNum,length(noPro0));
%% APF系数
paraMeters=[
    100,100,0,0;
    ];
%% 设置并行池
%parpool(12)
%% 并行用随机数种子
rng('default')
mainSeed = 1;
% 创建一个随机数流对象
% seeds = cell(1, repNum);
for i = 1:repNum
    seeds{i} = RandStream('mt19937ar', 'Seed', mainSeed + i);
end

Dimension0=[5,10,15,20];
result1=[];
R{length(Dimension0),length(paraMeters(:,1))}=[];
tic
for ii=1:length(Dimension0)
    Dimension=Dimension0(ii);
    for k=1:length(paraMeters(:,1))
        if isempty(R{ii,k})
            for i=1:length(noPro0)
                noPro=noPro0(length(noPro0)-i+1);
                tempfile=[noPro,paraMeters(k,:)];
                parfor j=1:repNum
                    %index(j)=j;
                    % 获取当前迭代的随机数流
                    currentStream = seeds{j};
                    % 设置当前工作者的随机数流
                    RandStream.setGlobalStream(currentStream);
                    [~,optimum_objs2(j,i),~] =func_APF_AFO_2(Dimension,VRmin,VRmax,tempfile);
                    disp([num2str(ii),'-',num2str(k),'-',num2str(i),'-',num2str(j),'-',num2str(optimum_objs2(j,i))])
                end
                temp=(sum(optimum_objs2(:,i))-min(optimum_objs2(:,i))-max(optimum_objs2(:,i)))/30;
                disp(num2str(temp));
            end
            R{ii,k}=optimum_objs2;
        end
        str=['CECE2020-R-',num2str(ii),'-',StrAlgorithm];
        save([str,date,'-', ...
            num2str(Dimension)],'R')
    end
end
tt=toc
disp(StrAlgorithm)
%%
